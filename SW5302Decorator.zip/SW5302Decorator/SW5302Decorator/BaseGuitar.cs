﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SW5302Decorator
{
    public class BaseGuitar : IGuitar
    {
        private readonly string name;
        private readonly double price;

        public BaseGuitar(string name,double price)
        {
            this.name = name;
            this.price = price;
        }
         string IGuitar.getName(string name)
        {
            return name;
        }

          double IGuitar.getPrice(double price)
        {
            return price;
        }

        public override string ToString()
        {
            return string.Format("Name: {0}, Cost: {1}",name,price);
        }
    }
}
