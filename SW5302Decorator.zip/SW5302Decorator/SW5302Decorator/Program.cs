﻿
using SW5302Decorator;

namespace Decorator
{
    class Program
    {
        static void Main()
        {
            
            Bass b1 = new Bass("Bass1", 500.00);
            Console.WriteLine(b1.ToString());

            
        }
    }
}